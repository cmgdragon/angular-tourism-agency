export class UserEducation {
  name: string;
  type: string;
  level: string;
  university: string;
  finish_date: string;
}
