# angular-tourism-agency

Activity for the Advanced front-end development courses from the [Master's Program in Web App and Website Development](https://estudis.uoc.edu/ca/masters-universitaris/desenvolupament-llocs-aplicacions-web/presentacio) at the [Universitat Oberta de Catalunya](https://www.uoc.edu).

# npm install
Install dependencies

# npm run database
For starting the simulated API

# ng serve
Run the app
